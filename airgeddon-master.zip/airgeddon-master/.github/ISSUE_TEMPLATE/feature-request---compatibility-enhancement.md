---
name: Feature request / compatibility enhancement
about: Suggest an idea for this project

---

<!--- Please, answer the questions to provide maximum of info -->
<!--- Filling this issue template is mandatory. Otherwise the issue can be directly closed -->
<!--- Write in English only -->
<!--- If additional info is required and requested by airgeddon's staff, you have 7 days to respond, otherwise the issue will be closed -->
<!--- Read the Issue Creation Policy on Contributing section before creating the issue -->

#### Describe the feature or compatibility enhancement and involved versions if apply

<!--- Insert answer here -->

#### What are the benefits of adding this?

<!--- Insert answer here -->
